package xyz.pangosoft.stuck;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StuckApplication {

	public static void main(String[] args) {
		SpringApplication.run(StuckApplication.class, args);
	}

}
