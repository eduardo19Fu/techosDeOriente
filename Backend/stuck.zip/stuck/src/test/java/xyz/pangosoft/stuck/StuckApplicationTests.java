package xyz.pangosoft.stuck;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StuckApplicationTests {

	@Test
	void contextLoads() {
	}

}
